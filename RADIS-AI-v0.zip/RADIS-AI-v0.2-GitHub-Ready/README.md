# RADIS-AI v0.2

GitHub-ready research prototype for a sophisticated AI-assisted radiology workspace.

## Run
Requires Node.js 18.17+.
1. `npm install`
2. `npm run dev`
3. Open `http://localhost:3000`

## Deploy
Import this repository into Vercel to get a public web URL.

## Important
AI findings shown in this version are simulated demonstration outputs. This is not a medical device and must not be used for diagnosis or treatment.

## Next milestone
Connect a Python/FastAPI inference API, real image upload, DICOM metadata, model adapters, explainability artifacts, and a research database.

## Architecture
RADIS is designed as an AI workflow layer around established medical imaging infrastructure. OHIF provides an extensible model of reusable extensions and task-specific modes; a future RADIS viewer mode can use that architecture rather than rebuilding a DICOM viewer from scratch.
